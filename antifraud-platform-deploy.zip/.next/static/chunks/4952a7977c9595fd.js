__turbopack_load_page_chunks__("/_app", [
  "static/chunks/c809543e87ccd683.js",
  "static/chunks/72370319bfefa479.js",
  "static/chunks/turbopack-02b8374bbbfbd86f.js"
])
