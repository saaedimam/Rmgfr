__turbopack_load_page_chunks__("/_error", [
  "static/chunks/1657953fad854c4a.js",
  "static/chunks/72370319bfefa479.js",
  "static/chunks/turbopack-7ccf6be6378acabc.js"
])
