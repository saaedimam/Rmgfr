var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__69744295._.js")
R.c("server/chunks/ssr/[root-of-the-server]__059d367d._.js")
R.m(3853)
module.exports=R.m(3853).exports
