var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__48d2e66b._.js")
R.m(12776)
module.exports=R.m(12776).exports
