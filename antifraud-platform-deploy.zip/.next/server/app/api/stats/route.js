var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/route.js")
R.c("server/chunks/[root-of-the-server]__b689ee73._.js")
R.c("server/chunks/[root-of-the-server]__849aba0a._.js")
R.m(75255)
R.m(98741)
module.exports=R.m(98741).exports
