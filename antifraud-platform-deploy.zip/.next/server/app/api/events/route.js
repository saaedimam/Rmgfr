var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/events/route.js")
R.c("server/chunks/[root-of-the-server]__f1e80f97._.js")
R.c("server/chunks/[root-of-the-server]__849aba0a._.js")
R.m(25966)
R.m(96946)
module.exports=R.m(96946).exports
