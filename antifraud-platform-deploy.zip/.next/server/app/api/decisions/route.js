var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/decisions/route.js")
R.c("server/chunks/[root-of-the-server]__a11f2ad3._.js")
R.c("server/chunks/[root-of-the-server]__849aba0a._.js")
R.m(84558)
R.m(81817)
module.exports=R.m(81817).exports
