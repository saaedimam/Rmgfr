var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/decisions/route.js")
R.c("server/chunks/[root-of-the-server]__ecdcd43a._.js")
R.c("server/chunks/[root-of-the-server]__849aba0a._.js")
R.m(30059)
R.m(52949)
module.exports=R.m(52949).exports
