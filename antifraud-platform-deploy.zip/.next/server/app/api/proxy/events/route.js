var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/proxy/events/route.js")
R.c("server/chunks/[root-of-the-server]__9d1d4519._.js")
R.c("server/chunks/[root-of-the-server]__849aba0a._.js")
R.m(74486)
R.m(27615)
module.exports=R.m(27615).exports
