var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[root-of-the-server]__2297e2a1._.js")
R.c("server/chunks/[root-of-the-server]__849aba0a._.js")
R.m(26046)
R.m(49443)
module.exports=R.m(49443).exports
